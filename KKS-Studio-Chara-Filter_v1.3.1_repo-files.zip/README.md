# Studio Chara Filter (KKS)

by **WolfLikesKKS** - https://github.com/WolfLikesKKS/KKS-Studio-Chara-Filter

A CharaStudio plugin for **Koikatsu Sunshine** that adds a filter window to the character list
(Add > Female / Male), and makes the list itself load much faster.

Filter thousands of cards by body sliders, outfits, zipmod content, missing mods, authors, name and folder,
without loading each card. A background index reads only the parts of each card it needs and caches them,
so after the first run the whole collection is searchable instantly.

## Features

### Where to look
- **Current folder**: filters whatever the list is showing (works with Browser Folders).
- **Choose folders**: tick one or more folders in a folder tree (with card counts, optional subfolders, search).
- **All folders**: every card in your collection, regardless of folder.
- **Name search**: character name or file name; several words must all match. Works in every scope.
- Large results are split into pages, with a **Show all** option.
- Counts and distribution graphs in the window follow the current scope (the missing mods report always covers all folders).

### Body
- **Anus size (ABMX)**: the scale of the anus bone from ABMX bone edits (100 = not edited; most cards aren't).
- Range sliders for any of the **47 body values** from the Maker body tab (all 44 shape sliders, plus areola size,
  bust softness and bust weight), plus anus size from ABMX. Choose which ones appear in F1. 11 common ones are shown by default.
- Two-handle sliders with number boxes for exact values. Add several ranges per value (e.g. `1-10, 35-40, 90`).
- A small distribution graph above each slider shows where your cards fall.
- The scale widens automatically for Slider Unlocker values. Handles at the ends include outliers.

### Face
- Range sliders for any of the **52 face sliders** from the Maker face tab (face shape, jaw, chin, cheeks, eyebrows, eyelids,
  eye position/size/angle, nose, mouth, ears), plus **iris width and height**. Choose which appear in F1 > Face sliders.

### Colors
- **Hair**, **eye** and **skin** color, sorted into simple buckets (black, brown, blonde, red, pink, blue, …; pale, fair, tan, dark).
  Tick colors to show only those cards.

### Body details
- Pubic hair, tan lines, body paint / tattoos, fangs (yaeba), futa (penis shown via Uncensor Selector), any ABMX bone edits:
  each *has* / *doesn't*. Plus a folding **nipple type** list (closed by default, with a selected count and Clear).
- **Hand size** and **foot size** sliders (ABMX bone scale) in the Body section, next to anus size.

### Profile (off by default, enable in F1 > Display)
- Personality, blood type, club, voice pitch, aggressive / diligence / kindness, the 23 **traits**, 9 **likes** and 5 **H refusals**.

### Card file
- **Added / modified**: last day, 7 / 30 / 90 days, last year, or older than a year.
- **Find duplicates**: the same character saved more than once (same name and identical face/body sliders), with **Show** to list every copy.
- **Unreadable files**: .png files in the card folders that aren't readable cards, with **Save list**.

### Clothing (outfits)
- Find characters with at least one outfit (in any slot) that is a **bath towel**, **nothing on**,
  **underwear / swimwear**, or **dressed**. Each can be set to *has one* or *none*.
- Filter by extra outfits (More Outfits) and by outfit name (e.g. "maid", "yukata").
- An optional per-slot table (Casual, Swimsuit, Pajamas, Bathing, Outfit 5+).

### Content mods (zipmods)
- Per body region (Hair, Head, Face, Neck & chest, Body & waist, Arms & hands, Legs, Clothing, Other):
  - **Uses mods**: does the card use zipmod items there?
  - **Missing**: are any of them not installed? For example, hide cards missing hair mods but keep
    cards that are only missing a strap or a beret.
- **Missing mods report**: every zipmod your cards use that isn't installed, sorted by how many cards need it,
  with name, author and website (from the cards themselves). Copy or open links one at a time,
  **open the next N sites** in batches (each site once), or save the full list to a text file.

### Installed zipmods not used by any card
- Information only: lists installed zipmods that none of your character cards (female or male) use, grouped by folder with sizes,
  so you can consider trimming a large mods folder (fewer zipmods = faster game startup).
- Only character cards are checked; Studio items, maps, scenes and Maker-only content can still need those mods.
  Studio / map packs are hidden by default. **Save list** writes everything to `UserData\StudioCharaFilter_UnusedZipmods.txt`.

### Genital type (Uncensor Selector)
- Lists which uncensor body each card asks Uncensor Selector for (with readable names where available), plus "Default" for cards without a choice.
  Tick one or more to show only those cards. Can be hidden in F1 > Display.

### Birthday (off by default, enable in F1 > Display > Show birthday filter)
- Cards store a birthday (month and day), not an age. Filter by birth month (tick any months), or by whether a birthday was set at all.
- May 17 is the Maker's default birthday, so it counts as "not set" by default (changeable in F1).

### Card authors
- Searchable list of card authors (from the Maker's author info) with counts. Tick authors to show their cards.

### Safe card removal (off by default, enable in F1 > Removed cards)
- When enabled, a collapsed **Card removal** section appears at the bottom of the filter window.
  **Remove highlighted card...** only works while a card is highlighted in the list, and asks once to confirm.
- The card is moved to `-UserRequest2Delete-` next to CharaStudio.exe, keeping its folder structure. Nothing is deleted.
- The same section lists removed cards with **Restore** to put a card back where it was.
- F1 > Removed cards: **Open folder**, or **Empty to Recycle Bin** (asks once). Even then, the cards can be recovered
  from the Windows Recycle Bin until it's emptied.
- Saved scenes aren't affected, because scenes store their own copy of each character.

### Speedups for CharaStudio itself (on by default, can be turned off in F1 > Performance)
- **Fast folder loading**: the character list reads names from the index instead of fully loading every card.
  Example: a 933-card folder went from ~3.8 s to ~13 ms. New or changed cards are still read normally.
- **Reuse list rows**: rows in the character list are kept and reused instead of destroyed and re-created every time the list changes,
  which speeds up switching folders and pages.
- **Fast thumbnails**: removes the stutter when moving the mouse over names, by caching thumbnails instead of
  running a full memory cleanup on every hover.

### Window and settings (F1)
- Draggable, resizable window with a scale setting for 1440p / 4K, an optional toggle hotkey,
  and a saved startup position (**Save current position** in F1).
- **Arrange** button: reorder the sections with ▲ ▼ (also in F1 > Window > Section order). Open/closed sections are remembered.
- F1 slider lists stay compact: Show all / Default set / Hide all, three saveable custom presets, and a fold-out checkbox list.
- Hover text on the main buttons.
- Optional legacy filter for which plugins saved data on a card (any / HAS / NOT).

## Requirements
- Koikatsu Sunshine with **BepInEx 5** and **KKSAPI** (included in HF Patch / BetterRepack).
- Optional: **Sideloader** (for missing-mod checks; included in HF Patch), **Browser Folders** (subfolder browsing).

## Installation
Download the zip from the [Releases](https://github.com/WolfLikesKKS/KKS-Studio-Chara-Filter/releases) page and extract it
into your game folder (the one with `CharaStudio.exe`), so that `KKS_StudioCharaFilter.dll` ends up in `BepInEx\plugins`. Open CharaStudio, then Add > Female.
The first time, the plugin indexes your cards in the background (progress is shown in the window).
After that, startup reads the cached index in well under a second and only re-reads new or changed cards.
Cards are read on several threads at once (F1 > Performance > Indexing threads).

The index cache is stored in `BepInEx\cache\StudioCharaFilter_*.idx`, and can be deleted at any time to rebuild it.

## Building from source
The build uses the C# compiler that ships with Windows and references the game's own DLLs.
No Visual Studio is needed.

1. Put this repository in a folder inside the game folder (e.g. `<game>\_ModDev`).
2. Run `build.bat`. It compiles `src\*.cs` and copies `KKS_StudioCharaFilter.dll` to `BepInEx\plugins`.
   Close CharaStudio first, because Windows locks the DLL while the game is running.

The code is limited to C# 5 (no `$""` strings, `?.` or `nameof`) because of the compiler that ships with Windows.
`decompile.bat` (optional) uses dnSpy.Console to decompile the game for reference into `decompiled\`.
That folder is git-ignored and must not be published.

## Settings
All settings are in the F1 menu under **Studio Chara Filter** (saved in `BepInEx\config\WolfLikesKKS.StudioCharaFilter.cfg`).

## Notes
- Body values are shown as Maker slider values (0-100).
- Missing-mod checks ask Sideloader whether each zipmod is installed. A mod that was renamed
  and is redirected by Sideloader may still show as missing.
- Not tested in VR. The English body slider names are translations of the game's Japanese names.
- Towels are recognized by item name ("towel" / タオル), or by the zipmod name for modded tops.
