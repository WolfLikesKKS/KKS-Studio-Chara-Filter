// User settings, shown in the F1 Configuration Manager under "Studio Chara Filter".
using BepInEx.Configuration;
using UnityEngine;

namespace StudioCharaFilter
{
    // Recognized by Configuration Manager by name; only the fields we use.
    internal sealed class ConfigurationManagerAttributes
    {
        public bool? Browsable;
        public int? Order;
        public System.Action<ConfigEntryBase> CustomDrawer;
        public bool? HideDefaultButton;
    }

    internal static class Settings
    {
        public static ConfigEntry<bool> ShowWindow;
        public static ConfigEntry<KeyboardShortcut> ToggleKey;
        public static ConfigEntry<float> WindowScale;
        public static ConfigEntry<bool> ShowHistograms;
        public static ConfigEntry<int> HistogramHeight;
        public static ConfigEntry<bool> ShowModIds;
        public static ConfigEntry<float> OutlierTrim;
        public static ConfigEntry<int> MaxResults;
        public static ConfigEntry<int> FolderListHeight;
        public static ConfigEntry<bool> LegacyPluginFilter;
        public static ConfigEntry<int> ListRowLimit;
        public static ConfigEntry<int> LinkBatchSize;
        public static ConfigEntry<bool> FastFolderLoading;
        public static ConfigEntry<bool> FastThumbnails;
        private static ConfigEntry<string> _removedCards;
        public static ConfigEntry<bool> EnableRemoval;
        private static bool _emptyConfirm;
        private static string _emptyMessage = "";
        public static ConfigEntry<string> WindowRect;
        public static int RectVersion; // bumped when the saved position changes, so the window reloads it

        public static void Init(ConfigFile cfg)
        {
            ShowWindow = cfg.Bind("Window", "Show filter window", true,
                Desc("Show the filter window while the Studio character list is open.", 10));
            ToggleKey = cfg.Bind("Window", "Toggle window hotkey", KeyboardShortcut.Empty,
                Desc("Shows/hides the filter window. Not set by default.", 9));
            WindowScale = cfg.Bind("Window", "Window scale", 1.0f,
                new ConfigDescription("Size of the filter window and its text. Try 1.25-1.5 on 1440p or 4K screens.",
                    new AcceptableValueRange<float>(0.75f, 2.5f), new ConfigurationManagerAttributes { Order = 8 }));

            ShowHistograms = cfg.Bind("Display", "Show distribution graphs", true,
                Desc("Show the small bar graph of where your cards fall above each body slider.", 10));
            HistogramHeight = cfg.Bind("Display", "Distribution graph height", 20,
                new ConfigDescription("Height of the bar graphs, in pixels (before window scale).",
                    new AcceptableValueRange<int>(10, 60), new ConfigurationManagerAttributes { Order = 9 }));
            ShowModIds = cfg.Bind("Display", "Show technical mod IDs", true,
                Desc("Show the plugin ID in gray next to each mod name in the Mod data list.", 8));
            OutlierTrim = cfg.Bind("Display", "Slider scale outlier trim (%)", 0.5f,
                new ConfigDescription("The slider scale ignores this percentage of the most extreme cards at each end, " +
                    "so a few odd cards don't squash the scale. Handles at the ends still include them.",
                    new AcceptableValueRange<float>(0f, 5f), new ConfigurationManagerAttributes { Order = 7 }));

            FolderListHeight = cfg.Bind("Display", "Folder list height", 320,
                new ConfigDescription("Height of the folder list in Choose folders mode, in pixels (before window scale).",
                    new AcceptableValueRange<int>(80, 800), new ConfigurationManagerAttributes { Order = 6 }));

            MaxResults = cfg.Bind("Behavior", "Cards per page", 1500,
                new ConfigDescription("Choose folders / All folders list this many cards per page (creating list rows is slow for huge lists). " +
                    "Use the page buttons or Show all in the window to see the rest.",
                    new AcceptableValueRange<int>(100, 10000)));
            EnableRemoval = cfg.Bind("Removed cards", "Enable card removal", false,
                new ConfigDescription("Adds a \"Card removal\" section at the bottom of the filter window, where the highlighted card can be moved to \"" +
                    Removal.FolderName + "\" next to CharaStudio.exe (nothing is deleted) and removed cards can be restored. Off by default.",
                    null, new ConfigurationManagerAttributes { Order = 10 }));
            _removedCards = cfg.Bind("Removed cards", "Removed cards folder", "",
                new ConfigDescription("Cards removed with \"Remove card...\" are moved to \"" + Removal.FolderName + "\" next to CharaStudio.exe. " +
                    "Emptying sends them to the Windows Recycle Bin, so they can still be recovered from there.", null,
                    new ConfigurationManagerAttributes { CustomDrawer = DrawRemovedCards, HideDefaultButton = true }));
            FastFolderLoading = cfg.Bind("Performance", "Fast folder loading", true,
                "Suggested to keep on: speeds up opening character folders in Studio by reading card names from this plugin's index " +
                "instead of loading every card in full. New or changed cards are still read normally. " +
                "Feel free to disable if it causes issues.");
            FastThumbnails = cfg.Bind("Performance", "Fast thumbnails", true,
                "Suggested to keep on: removes the stutter when moving the mouse over character names by caching thumbnails " +
                "instead of running a full memory cleanup on every hover. Feel free to disable if it causes issues.");
            LinkBatchSize = cfg.Bind("Behavior", "Missing mod sites per batch", 5,
                new ConfigDescription("How many missing-mod websites the \"Open next sites\" button opens in your browser at once. " +
                    "Each site is opened once even if several missing mods share it.",
                    new AcceptableValueRange<int>(1, 50)));
            LegacyPluginFilter = cfg.Bind("Behavior", "Show plugin data filter (legacy)", false,
                "Show the older filter that includes/excludes cards by which plugins saved data on them (any / HAS / NOT).");
            ListRowLimit = cfg.Bind("Display", "Max rows in author / plugin lists", 150,
                new ConfigDescription("Long lists in the window only draw this many rows at a time; use the search box to find the rest.",
                    new AcceptableValueRange<int>(30, 2000), new ConfigurationManagerAttributes { Order = 5 }));

            WindowRect = cfg.Bind("Window", "Startup position", "",
                new ConfigDescription("Where the window opens on startup. Move/resize the window, then press Save here. " +
                    "Empty = default spot (right side of the screen).", null,
                    new ConfigurationManagerAttributes { Order = 7, CustomDrawer = DrawPositionSetting, HideDefaultButton = true }));
            WindowRect.SettingChanged += (s, e) => RectVersion++;
        }

        private static void DrawRemovedCards(ConfigEntryBase entry)
        {
            int count = Removal.Entries().Count;
            GUILayout.BeginVertical();
            GUILayout.BeginHorizontal();
            GUILayout.Label(count + " removed cards", GUILayout.ExpandWidth(true));
            if (GUILayout.Button("Open folder", GUILayout.ExpandWidth(false))) Removal.OpenFolder();
            if (!_emptyConfirm)
            {
                GUI.enabled = count > 0;
                if (GUILayout.Button("Empty to Recycle Bin...", GUILayout.ExpandWidth(false)))
                {
                    _emptyConfirm = true;
                    _emptyMessage = "";
                }
                GUI.enabled = true;
            }
            GUILayout.EndHorizontal();
            if (_emptyConfirm)
            {
                GUILayout.Label("Send all " + count + " removed cards to the Windows Recycle Bin?");
                GUILayout.BeginHorizontal();
                if (GUILayout.Button("Yes, send to Recycle Bin", GUILayout.ExpandWidth(false)))
                {
                    _emptyMessage = Removal.EmptyToRecycleBin();
                    _emptyConfirm = false;
                }
                if (GUILayout.Button("Cancel", GUILayout.ExpandWidth(false))) _emptyConfirm = false;
                GUILayout.EndHorizontal();
            }
            if (_emptyMessage.Length > 0) GUILayout.Label(_emptyMessage);
            GUILayout.EndVertical();
        }

        private static void DrawPositionSetting(ConfigEntryBase entry)
        {
            GUILayout.BeginHorizontal();
            GUILayout.Label(string.IsNullOrEmpty(WindowRect.Value) ? "default" : WindowRect.Value, GUILayout.ExpandWidth(true));
            if (GUILayout.Button("Save current position", GUILayout.ExpandWidth(false)))
            {
                Rect r = FilterWindow.CurrentRect;
                if (r.width > 1) WindowRect.Value = string.Format("{0:0},{1:0},{2:0},{3:0}", r.x, r.y, r.width, r.height);
            }
            if (GUILayout.Button("Reset", GUILayout.ExpandWidth(false)))
                WindowRect.Value = "";
            GUILayout.EndHorizontal();
        }

        private const string SliderSection = "Body sliders shown";
        private static FilterState _bodyFilter;
        private static System.Action _onSlidersChanged;
        private static ConfigEntry<string> _sliderQuick;

        // One on/off toggle per body slider, plus quick buttons. Hiding a slider also clears its filter.
        public static void BindBodySliders(ConfigFile cfg, FilterState filter, System.Action onChanged)
        {
            _bodyFilter = filter;
            _onSlidersChanged = onChanged;
            _sliderQuick = cfg.Bind(SliderSection, "Quick select", "",
                new ConfigDescription("Show every body slider, only the default set, or none.", null,
                    new ConfigurationManagerAttributes { Order = 1000, CustomDrawer = DrawSliderQuick, HideDefaultButton = true }));
            int order = 999;
            foreach (PropertyFilter p in filter.Properties)
            {
                PropertyFilter prop = p;
                prop.Shown = cfg.Bind(SliderSection, prop.Label, prop.DefaultShown,
                    new ConfigDescription("Show the " + prop.Label + " slider in the filter window. Hiding it also clears its filter.",
                        null, new ConfigurationManagerAttributes { Order = order-- }));
                prop.Shown.SettingChanged += (sender, args) =>
                {
                    if (!prop.Shown.Value) prop.Reset();
                    if (_onSlidersChanged != null) _onSlidersChanged();
                };
            }
        }

        private static void DrawSliderQuick(ConfigEntryBase entry)
        {
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("Show all", GUILayout.ExpandWidth(false))) SetAllSliders(0);
            if (GUILayout.Button("Default set", GUILayout.ExpandWidth(false))) SetAllSliders(1);
            if (GUILayout.Button("Hide all", GUILayout.ExpandWidth(false))) SetAllSliders(2);
            GUILayout.EndHorizontal();
        }

        private static void SetAllSliders(int mode)
        {
            if (_bodyFilter == null) return;
            foreach (PropertyFilter p in _bodyFilter.Properties)
            {
                bool v = mode == 0 || (mode == 1 && p.DefaultShown);
                if (p.Shown != null && p.Shown.Value != v) p.Shown.Value = v;
            }
        }

        private static ConfigDescription Desc(string text, int order)
        {
            return new ConfigDescription(text, null, new ConfigurationManagerAttributes { Order = order });
        }

        public static Rect LoadRect()
        {
            string[] p = (WindowRect.Value ?? "").Split(',');
            float x, y, w, h;
            if (p.Length == 4 && float.TryParse(p[0], out x) && float.TryParse(p[1], out y) &&
                float.TryParse(p[2], out w) && float.TryParse(p[3], out h) && w > 50 && h > 50)
                return new Rect(x, y, w, h);
            return new Rect(0, 0, 0, 0);
        }

    }
}
