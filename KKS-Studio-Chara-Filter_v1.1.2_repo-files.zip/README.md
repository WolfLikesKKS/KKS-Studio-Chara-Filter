# Studio Chara Filter (KKS)

by **WolfLikesKKS** - https://github.com/WolfLikesKKS/KKS-Studio-Chara-Filter

A CharaStudio plugin for **Koikatsu Sunshine** that adds a filter window to the character list
(Add > Female / Male), and makes the list itself load much faster.

Filter thousands of cards by body sliders, outfits, zipmod content, missing mods, authors, name and folder,
without loading each card. A background index reads only the parts of each card it needs and caches them,
so after the first run the whole collection is searchable instantly.

## Features

### Where to look
- **Current folder**: filters whatever the list is showing (works with Browser Folders).
- **Choose folders**: tick one or more folders in a folder tree (with card counts, optional subfolders, search).
- **All folders**: every card in your collection, regardless of folder.
- **Name search**: character name or file name; several words must all match. Works in every scope.
- Large results are split into pages, with a **Show all** option.
- Counts and distribution graphs in the window follow the current scope (the missing mods report always covers all folders).

### Body
- Range sliders for any of the **47 body values** from the Maker body tab (all 44 shape sliders, plus areola size,
  bust softness and bust weight). Choose which ones appear in F1. 11 common ones are shown by default.
- Two-handle sliders with number boxes for exact values. Add several ranges per value (e.g. `1-10, 35-40, 90`).
- A small distribution graph above each slider shows where your cards fall.
- The scale widens automatically for Slider Unlocker values. Handles at the ends include outliers.

### Clothing (outfits)
- Find characters with at least one outfit (in any slot) that is a **bath towel**, **nothing on**,
  **underwear / swimwear**, or **dressed**. Each can be set to *has one* or *none*.
- Filter by extra outfits (More Outfits) and by outfit name (e.g. "maid", "yukata").
- An optional per-slot table (Casual, Swimsuit, Pajamas, Bathing, Outfit 5+).

### Content mods (zipmods)
- Per body region (Hair, Head, Face, Neck & chest, Body & waist, Arms & hands, Legs, Clothing, Other):
  - **Uses mods**: does the card use zipmod items there?
  - **Missing**: are any of them not installed? For example, hide cards missing hair mods but keep
    cards that are only missing a strap or a beret.
- **Missing mods report**: every zipmod your cards use that isn't installed, sorted by how many cards need it,
  with name, author and website (from the cards themselves). Copy or open links one at a time,
  **open the next N sites** in batches (each site once), or save the full list to a text file.

### Card authors
- Searchable list of card authors (from the Maker's author info) with counts. Tick authors to show their cards.

### Safe card removal (off by default, enable in F1 > Removed cards)
- When enabled, a collapsed **Card removal** section appears at the bottom of the filter window.
  **Remove highlighted card...** only works while a card is highlighted in the list, and asks once to confirm.
- The card is moved to `-UserRequest2Delete-` next to CharaStudio.exe, keeping its folder structure. Nothing is deleted.
- The same section lists removed cards with **Restore** to put a card back where it was.
- F1 > Removed cards: **Open folder**, or **Empty to Recycle Bin** (asks once). Even then, the cards can be recovered
  from the Windows Recycle Bin until it's emptied.
- Saved scenes aren't affected, because scenes store their own copy of each character.

### Speedups for CharaStudio itself (on by default, can be turned off in F1 > Performance)
- **Fast folder loading**: the character list reads names from the index instead of fully loading every card.
  Example: a 933-card folder went from ~3.8 s to ~13 ms. New or changed cards are still read normally.
- **Fast thumbnails**: removes the stutter when moving the mouse over names, by caching thumbnails instead of
  running a full memory cleanup on every hover.

### Window and settings (F1)
- Draggable, resizable window with a scale setting for 1440p / 4K, an optional toggle hotkey,
  and a saved startup position (**Save current position** in F1).
- Hover text on the main buttons.
- Optional legacy filter for which plugins saved data on a card (any / HAS / NOT).

## Requirements
- Koikatsu Sunshine with **BepInEx 5** and **KKSAPI** (included in HF Patch / BetterRepack).
- Optional: **Sideloader** (for missing-mod checks; included in HF Patch), **Browser Folders** (subfolder browsing).

## Installation
Download the zip from the [Releases](https://github.com/WolfLikesKKS/KKS-Studio-Chara-Filter/releases) page and extract it
into your game folder (the one with `CharaStudio.exe`), so that `KKS_StudioCharaFilter.dll` ends up in `BepInEx\plugins`. Open CharaStudio, then Add > Female.
The first time, the plugin indexes your cards in the background (progress is shown in the window).
After that, startup reads the cached index in well under a second and only re-reads new or changed cards.

The index cache is stored in `BepInEx\cache\StudioCharaFilter_*.idx`, and can be deleted at any time to rebuild it.

## Building from source
The build uses the C# compiler that ships with Windows and references the game's own DLLs.
No Visual Studio is needed.

1. Put this repository in a folder inside the game folder (e.g. `<game>\_ModDev`).
2. Run `build.bat`. It compiles `src\*.cs` and copies `KKS_StudioCharaFilter.dll` to `BepInEx\plugins`.
   Close CharaStudio first, because Windows locks the DLL while the game is running.

The code is limited to C# 5 (no `$""` strings, `?.` or `nameof`) because of the compiler that ships with Windows.
`decompile.bat` (optional) uses dnSpy.Console to decompile the game for reference into `decompiled\`.
That folder is git-ignored and must not be published.

## Settings
All settings are in the F1 menu under **Studio Chara Filter** (saved in `BepInEx\config\WolfLikesKKS.StudioCharaFilter.cfg`).

## Notes
- Body values are shown as Maker slider values (0-100).
- Missing-mod checks ask Sideloader whether each zipmod is installed. A mod that was renamed
  and is redirected by Sideloader may still show as missing.
- Not tested in VR. The English body slider names are translations of the game's Japanese names.
- Towels are recognized by item name ("towel" / タオル), or by the zipmod name for modded tops.
